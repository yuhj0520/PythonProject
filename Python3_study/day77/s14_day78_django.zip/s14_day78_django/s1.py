

# class Person:
#     def __init__(self,name):
#         self.name=name
#     def __setitem__(self, key, value):
#         setattr(self,key,value)  #反射
#     def __getitem__(self, item):
#         return getattr(self,item) # 反射取值
#
# p=Person('lqz')
# # p.name='ppp'
# p['name']=10 # 如何变行 重写__setitem__魔法方法
# # print(p.name)
#
# print(p['name'])


# dic={'name':'lqz','age':19}

# class Mydic(dict):
#     def __setattr__(self, key, value):
#         print("对象加点赋值，会触发我")
#         self[key]=value
#     def __getattr__(self, item):
#         print("对象加点取值，会触发我")
#         return self[item] # 不要加引号
#
# mydic=Mydic(name='lqz',age=18)
# # print(mydic['name'])
# print(mydic.name)
# # mydic.name=99
# # print(mydic.name)




#__enter__和__exit__

# class Mysql:
#     def __enter__(self):
#         print("我在with管理的时候，会触发")
#         print('进入with语句块时执行此方法，此方法如果有返回值会赋值给as声明的变量')
#         self.conn=pymysql.connet()
#         return conn
#
#     def __exit__(self, exc_type, exc_val, exc_tb):
#         self.conn.close()
#         print('退出with代码块时执行此方法')
#         print('1', exc_type)
#         print('2', exc_val)
#         print('3', exc_tb)
#
#
# with Mysql() as conn:   # 这句话执行，会触发类的__enter__
    # 查询语句
# 当缩进完了，会触发__exit__执行


# len(对象)   对象.__len__()


# __eq__
# object
# class A:
#     def __init__(self,x,y):
#         self.x = x
#         self.y = y
#
#     # def __eq__(self,obj):
#     #     # 打印出比较的第二个对象的x值
#     #     print(obj.x)
#     #     if self.x +self.y == obj.x+obj.y:
#     #         return True
#     #     else:
#     #         return False
#
# a=A(1,2)
# b=A(99,3)
# print(a=='ddd')   # 当执行==s时，会触发__eq__的执行，并且把b传进去，就是object
# # ==后只要是对象，就可以传进去，就是object



# try:
#     print("xxx")
#     # print(1/0)
# except Exception as e:
#     print(e)
# else:  # 基本上不会用到
#     print("正常执行，没有出异常，会走")
# finally:
#     print("我是finally")   # 用于会走，无论是否有异常



import pymysql


#连接数据库
conn=pymysql.connect(host='101.133.225.166', user='root', password="123456",database='test', port=3306) #
# 获取游标
cursor=conn.cursor(cursor=pymysql.cursors.DictCursor) # 查出来数据是字典格式
# 操作 定义一个sql
# sql='select id,name from book'
# cursor.execute(sql)
# ret=cursor.fetchall()
# print(ret)
# 插入
# sql='insert into book(id,name) values (%s,%s)'
# cursor.execute(sql,[3,'lqz'])
# conn.commit()

# 删除
# sql='delete from book where name=%s'
# cursor.execute(sql,['lqz'])
# conn.commit()

# 更新
# sql='update book set name=%s where id=%s'
# cursor.execute(sql,['xxx',1])
# conn.commit()

