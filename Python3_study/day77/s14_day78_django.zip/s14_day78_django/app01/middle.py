
from django.utils.deprecation import MiddlewareMixin

import json
class JsonMiddel(MiddlewareMixin):
    def process_request(self, request):
        try:
            request.data=json.loads(request.body)
        except Exception as e:
            request.data=request.POST

