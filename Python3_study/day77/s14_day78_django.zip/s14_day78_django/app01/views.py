from django.shortcuts import render,HttpResponse

# Create your views here.

def index(request):
    if request.method=='GET':
        request.session['name']='lqz'
        print(type(request.session))
        from django.contrib.sessions.backends.db import SessionStore
        return render(request,'index.html')
    else:
        from django.http.request import QueryDict
        print(request.POST)
        print(type(request.POST))
        print('body的内容：',request.body)
        print(request.data.get('name'))
        return HttpResponse('ok')