from django.shortcuts import render,HttpResponse

# Create your views here.



from rest_framework.viewsets import ModelViewSet
from .models import Book
from .ser import BookModelSerializer

from django.views import View
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.request import Request

class BooksViewSet(ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookModelSerializer


class Books(View):
    #如果有个需求，只能接受get请求
    http_method_names = ['get',]
    def get(self,request):
        print(self.request)
        return HttpResponse('ok')

class BooksAPIView(APIView):

    def get(self,request):
        # request 已经不是原生django的request了，是drf自己定义的request对象
        # print(request._request)
        # print(request.data)
        print(request.method)
        print(request.query_params)  #get请求，地址中的参数
        # 原来在
        print(request.GET)
        return HttpResponse('ok')

    def post(self,request):

        print(request.data) # urlencoded方式有数据，json格式也有，formdata也有数据
        print(type(request.POST)) # 原生的POST
        print(request._request.POST)

        from django.http.request import QueryDict


        return HttpResponse('ok')

