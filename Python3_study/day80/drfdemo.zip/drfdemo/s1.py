


def foo(a,b):
    return a+b


foo.name='lqz'  #由于一切皆对象，函数也是个对象，对象放值

print(foo(2,3))

print(foo.name)