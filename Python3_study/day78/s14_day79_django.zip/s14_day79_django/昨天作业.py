# 第一道

# 自定义异常
# class  NotStrException(BaseException):
#     def __init__(self,msg):
#         self.msg=msg
#     def __str__(self):
#         return self.msg
#
#
# class Person():
#     def __setattr__(self, key, value):
#         if isinstance(value,str):  #isinstance   issubclass
#             # setattr(self,key,value)   #内部是这么执行的self.key=value
#             # self.__dict__[key]=value
#             object.__setattr__(self,key,value)
#         else:
#             # print("你不能放")
#             raise NotStrException('不是字符串异常')
#
# person=Person()
#
# try:
#     # person.name=99
#     person.name='lqz'
# except NotStrException as e:
#     print(e)
#
# print(person.name)


## 第二道
# import pymysql
# class Mysql():
#     def __enter__(self):
#
#         self.conn=pymysql.connect(host='127.0.0.1', user='root', password="123456",
#                  database='mytest', port=3306)
#         return self.conn  # 会被as 后的对象拿到
#
#     def __exit__(self, exc_type, exc_val, exc_tb):
#         self.conn.close()
#
#
# with Mysql() as mysql:
#     mysql.cursor()


