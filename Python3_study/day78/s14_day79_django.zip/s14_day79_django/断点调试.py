



def wrapper(func):
    def inner(*args,**kwargs):
        print("之前")
        ret=func(*args,**kwargs)
        print('之后')
        return ret
    return inner

def wrapper2(func):
    def inner(*args,**kwargs):
        print("wrapper2之前")
        ret=func(*args,**kwargs)
        print('wrapper2之后')
        return ret
    return inner
def wrapper3(func):
    def inner(*args,**kwargs):
        print("wrapper3之前")
        ret=func(*args,**kwargs)
        print('wrapper3之后')
        return ret
    return inner


def foo1(a,b):
    print(a+b)
    1/0
    return a+b
def foo2():
    print('foo2,foo2')
    foo1(3,4)
    return True

@wrapper
# @wrapper2
# @wrapper3
def test():
    foo2()
    print("test2")
    foo1(6,7)
if __name__ == '__main__':
    print('my name is lqz')
    a=100
    print(a)
    test()   # 快速跳到下一个断电，点一下左侧绿箭头
    print('sdfadfasfas')

#第一步：打断点鼠标左键点一下，有个红点，表示打了一个断电，如果断点调试，程序走到这卡主，除非你让他继续往下走，否则它会卡在这
# 第二步：以debug模式运行
# 第三：快速跳到下一个断点：左侧的绿箭头
# 第四：单步调试：跳到函数内部，把函数运行当做一句话
# 第五：左侧的红点带斜杆，表示快速把所有断点都设置为灰色
# 单步调试：一步一步走