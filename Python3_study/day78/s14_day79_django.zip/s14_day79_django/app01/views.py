from django.shortcuts import render,HttpResponse
from django.http import JsonResponse

# Create your views here.
# def index(re,id):
#     print(id)
#     re.session['aa']="aa"
#     # return HttpResponse('ok')
#     return  JsonResponse({'name':'lqz'},json_dumps_params={'ensure_ascii':False})


# def index(request):
#     if request.method=='GET':
#
#         return  render(request,'index.html')
#     else:
#         myfile=request.FILES.get('myfile')  #文件对象
#         print(type(myfile))
#         from django.core.files.uploadedfile import InMemoryUploadedFile
#         name=myfile.name
#         print(myfile.field_name)
#         with open(name,'wb') as f:
#             for line in myfile:
#                 f.write(line)
#         return HttpResponse('文件上传成功')
#
# def test():
#     print("xxx")
# def template_test(request):
#     name = 'lqz'
#     li = ['lqz', 1, '18']
#     dic = {'name': 'lqz', 'age': 18}
#     ll2 = [
#         {'name': 'lqz', 'age': 18},
#         {'name': 'lqz2', 'age': 19},
#         {'name': 'egon', 'age': 20},
#         {'name': 'kevin', 'age': 23}
#     ]
#     ll3=[]
#     class Person:
#         def __init__(self, name):
#             self.name = name
#
#         def test(self):
#             print('test函数')
#             return 11
#
#         @classmethod
#         def test_classmethod(cls):
#             print('类方法')
#             return '类方法'
#
#         @staticmethod
#         def static_method():
#             print('静态方法')
#             return '静态方法'
#
#     lqz = Person('lqz')
#     egon = Person('egon')
#     person_list = [lqz, egon]
#     bo = True
#     te = test()
#     import datetime
#     now=datetime.datetime.now()
#     link1='<a href="https://www.baidu.com">点我<a>'
#     from django.utils import safestring
#     link=safestring.mark_safe(link1)
#     # html特殊符号对照表（http://tool.chinaz.com/Tools/htmlchar.aspx）
#
#     # 这样传到前台不会变成特殊字符，因为django给处理了
#     dot='&spades;'
#     aa=[[1,2],[3,4]]
#
#
#     # return render(request, 'template_index.html', {'name':name,'person_list':person_list})
#     return render(request, 'template_index.html', locals())



