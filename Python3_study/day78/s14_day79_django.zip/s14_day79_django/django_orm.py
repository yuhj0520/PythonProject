

import os
if __name__ == '__main__':
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "s14_day79_django.settings")
    import django
    django.setup()

    from app01 import models

    # books = models.Book.objects.all()
    # print(books)
    # auth=models.Author.objects.all().first()
    # print(auth)
    # print(auth.book_set.all())

    books = models.Book.objects.all().first()
    print(books.authors.all())
    # books.authors.remove(1)
    # books.authors.clear()
    books.authors.set(1,2)