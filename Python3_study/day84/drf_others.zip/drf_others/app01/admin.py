from django.contrib import admin

# Register your models here.

from app01.models import Book
admin.site.register(Book)