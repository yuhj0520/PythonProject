


a=(3,)
a=3,
print(type(a))